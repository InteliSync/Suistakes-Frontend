=== CTL Slot Ultimate Soccer ===
Tags: casino, casino game, soccer, gambling, html5 casino, instant win, football game, poker, slot, slot machine, videopoker,sweepstakes, lottery, soccer game, sport game
Requires at least: 4.3
Tested up to: 4.3

Add Slot Ultimate Soccer to CTL Arcade plugin

== Description ==
Add Slot Ultimate Soccer to CTL Arcade plugin


	