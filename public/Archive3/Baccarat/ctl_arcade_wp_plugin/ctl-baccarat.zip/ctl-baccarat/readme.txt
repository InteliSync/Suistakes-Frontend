=== CTL Baccarat ===
Tags: 3d game, baccarat, baccarat table, card, cards, casino, casino game, baccara, gambling, html5 gambling, html5 baccarat, html5 casino, mobile, poker, sweepstakes
Requires at least: 4.3
Tested up to: 4.3

Add Baccarat to CTL Arcade plugin

== Description ==
Add Baccarat to CTL Arcade plugin


	