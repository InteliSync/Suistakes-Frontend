=== CTL Yacht Dice Game ===
Tags: board game, cheerio,craps,dices,farkle,five dice,generala,poker dice,yacht,yachty,yahtzee,yatzie,yatzy
Requires at least: 4.3
Tested up to: 4.3

Add Yacht Dice Game to CTL Arcade plugin

== Description ==
Add Yacht Dice Game to CTL Arcade plugin


	