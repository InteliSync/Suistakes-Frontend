=== CTL Craps ===
Tags: 3d game, craps, craps table, bet, instant win, casino, casino game, baccara, gambling, html5 gambling, html5 craps, html5 casino, mobile, poker, sweepstakes
Requires at least: 4.3
Tested up to: 4.3

Add Craps to CTL Arcade plugin

== Description ==
Add Craps to CTL Arcade plugin


	