=== CTL Slot Zeus Treasures ===
Tags: mythology, casino, gambling, html5 slot machine, instant win, money, poker, slot, slot machine, bonus, html5 slot game, sweepstakes, lottery
Requires at least: 4.3
Tested up to: 4.3

Add Slot Zeus Treasures to CTL Arcade plugin

== Description ==
Add Slot Zeus Treasures to CTL Arcade plugin


	